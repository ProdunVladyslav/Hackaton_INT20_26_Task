import { useCallback, useRef } from 'react'
import ReactFlow, {
  Background,
  Controls,
  MiniMap,
  BackgroundVariant,
  useReactFlow,
} from 'reactflow'
import type { DragEvent } from 'react'
import 'reactflow/dist/style.css'
import styled, { useTheme } from 'styled-components'
import { useDagStore } from '../store/dag.store'
import { NodePalette } from './NodePalette'
import { PropertiesPanel } from './PropertiesPanel'
import { QuestionNode } from './nodes/QuestionNode'
import { InfoNode } from './nodes/InfoNode'
import { OfferNode } from './nodes/OfferNode'
import { NodeType } from '@shared/types/dag.types'
import type { DagNodeData, QuestionNodeData, InfoNodeData, OfferNodeData } from '@shared/types/dag.types'
import { AttributeKey, AnswerType } from '@shared/types/dag.types'
import type { Node } from 'reactflow'

const nodeTypes = {
  [NodeType.Question]: QuestionNode,
  [NodeType.Info]: InfoNode,
  [NodeType.Offer]: OfferNode,
}

const CanvasWrapper = styled.div`
  flex: 1;
  position: relative;
  overflow: hidden;
`

const EditorLayout = styled.div`
  display: flex;
  height: 100%;
  overflow: hidden;
`

function createNodeData(type: NodeType): DagNodeData {
  switch (type) {
    case NodeType.Question:
      return {
        type: NodeType.Question,
        questionText: 'New question',
        attribute: AttributeKey.Goal,
        answerType: AnswerType.SingleChoice,
        options: [],
      } satisfies QuestionNodeData
    case NodeType.Info:
      return {
        type: NodeType.Info,
        title: 'New info screen',
        body: '',
      } satisfies InfoNodeData
    case NodeType.Offer:
      return {
        type: NodeType.Offer,
        headline: 'New offer',
        description: '',
        ctaText: 'Get Started',
      } satisfies OfferNodeData
  }
}

export function DagCanvas() {
  const theme = useTheme()
  const reactFlowWrapper = useRef<HTMLDivElement>(null)
  const { screenToFlowPosition } = useReactFlow()

  const nodes = useDagStore((s) => s.nodes)
  const edges = useDagStore((s) => s.edges)
  const onNodesChange = useDagStore((s) => s.onNodesChange)
  const onEdgesChange = useDagStore((s) => s.onEdgesChange)
  const onConnect = useDagStore((s) => s.onConnect)
  const addNode = useDagStore((s) => s.addNode)
  const setSelectedNode = useDagStore((s) => s.setSelectedNode)
  const setSelectedEdge = useDagStore((s) => s.setSelectedEdge)

  const onDragStart = useCallback((e: DragEvent, type: NodeType) => {
    e.dataTransfer.setData('application/reactflow', type)
    e.dataTransfer.effectAllowed = 'move'
  }, [])

  const onDragOver = useCallback((e: DragEvent) => {
    e.preventDefault()
    e.dataTransfer.dropEffect = 'move'
  }, [])

  const onDrop = useCallback(
    (e: DragEvent) => {
      e.preventDefault()
      const type = e.dataTransfer.getData('application/reactflow') as NodeType
      if (!type) return

      const position = screenToFlowPosition({ x: e.clientX, y: e.clientY })
      const newNode: Node<DagNodeData> = {
        id: crypto.randomUUID(),
        type,
        position,
        data: createNodeData(type),
      }
      addNode(newNode)
    },
    [screenToFlowPosition, addNode]
  )

  return (
    <EditorLayout>
      <NodePalette onDragStart={onDragStart} />
      <CanvasWrapper ref={reactFlowWrapper}>
        <ReactFlow
          nodes={nodes}
          edges={edges}
          nodeTypes={nodeTypes}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          onConnect={onConnect}
          onDragOver={onDragOver}
          onDrop={onDrop}
          onNodeClick={(_, node) => setSelectedNode(node.id)}
          onEdgeClick={(_, edge) => setSelectedEdge(edge.id)}
          onPaneClick={() => {
            setSelectedNode(null)
            setSelectedEdge(null)
          }}
          fitView
          snapToGrid
          snapGrid={[16, 16]}
          defaultEdgeOptions={{ type: 'smoothstep', animated: false }}
          proOptions={{ hideAttribution: true }}
        >
          <Background
            variant={BackgroundVariant.Dots}
            gap={20}
            size={1}
            color={theme.colors.border}
          />
          <Controls
            style={{
              background: theme.colors.bgSurface,
              border: `1px solid ${theme.colors.border}`,
              borderRadius: theme.radii.md,
            }}
          />
          <MiniMap
            nodeColor={(n) => {
              switch (n.type) {
                case NodeType.Question: return theme.colors.nodeQuestion
                case NodeType.Info: return theme.colors.nodeInfo
                case NodeType.Offer: return theme.colors.nodeOffer
                default: return theme.colors.border
              }
            }}
            style={{
              background: theme.colors.bgSurface,
              border: `1px solid ${theme.colors.border}`,
              borderRadius: theme.radii.md,
            }}
          />
        </ReactFlow>
      </CanvasWrapper>
      <PropertiesPanel />
    </EditorLayout>
  )
}
